<style type="text/css">
<!--
.style2 {color: #990000}
.style3 {font-size: 18px}
-->
</style>
<p align="center" class="style3"><strong>Disabled in Basic Version</strong></p>
<p align="center" class="style3"><strong><a href="http://phpsoftwares.com/" target="_blank" class="style2"><u>Upgrade</u></a> to full version for just 14.99$ only. <u>100% Source Code</u> <a href="http://phpsoftwares.com/" target="_blank"><u><span class="style2">www.PhpSoftwares.com</span> </u></a></strong></p>
<form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_top">
<div align="center">
  <input type="hidden" name="cmd" value="_s-xclick">
  <input type="hidden" name="hosted_button_id" value="4BKA5ZHWXARDU">
</div>
<table>
<tr><td><input type="hidden" name="on0" value="Select Software:">Upgrade Software:</td></tr><tr><td><select name="os0">
	<option value="School Software">School Software $14.99 USD</option>
	<option value="Hospital Software">Hospital Software $9.99 USD</option>
	<option value="POS Billing Software">POS Billing Software $14.99 USD</option>
	<option value="All 3 Softwares">All 3 Softwares $29.99 USD</option>
</select> </td></tr>
</table>
<input type="hidden" name="currency_code" value="USD">
<input type="image" src="https://www.paypalobjects.com/en_GB/i/btn/btn_buynowCC_LG.gif" border="0" name="submit" alt="PayPal � The safer, easier way to pay online.">
<img alt="" border="0" src="https://www.paypalobjects.com/en_GB/i/scr/pixel.gif" width="1" height="1">
</form>
<img src="uploads/images/teacher/studymaterial_teacher.PNG" width="1063" height="343" />