<!-- Footer -->
<footer class="main">
	&copy; 2016 optimumlinkup.com.ng <strong> School Manager</strong>. 
    Developed by Optimum Linkup </footer>
