<?php

class Services_Twilio_Rest_AvailablePhoneNumber
    extends Services_Twilio_InstanceResource
{
}

