<?php

class Services_Twilio_Rest_TaskRouter_TaskQueue extends Services_Twilio_TaskRouterInstanceResource {

}
