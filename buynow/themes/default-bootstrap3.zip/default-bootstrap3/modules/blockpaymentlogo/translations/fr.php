<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockpaymentlogo}leo_hitechgame>blockpaymentlogo_eaaf494f0c90a2707d768a9df605e94b'] = 'Bloc des logos de paiement';
$_MODULE['<{blockpaymentlogo}leo_hitechgame>blockpaymentlogo_3fd11fa0ede1bd0ace9b3fcdbf6a71c9'] = 'Ajoute un bloc qui affiche tous vos logos de paiement.';
$_MODULE['<{blockpaymentlogo}leo_hitechgame>blockpaymentlogo_b15e7271053fe9dd22d80db100179085'] = 'Ce module nécessite d\'être greffé sur une colonne, mais votre thème n\'a pas de colonne';
$_MODULE['<{blockpaymentlogo}leo_hitechgame>blockpaymentlogo_efc226b17e0532afff43be870bff0de7'] = 'Paramètres mis à jour';
$_MODULE['<{blockpaymentlogo}leo_hitechgame>blockpaymentlogo_5c5e5371da7ab2c28d1af066a1a1cc0d'] = 'Aucune page CMS n\'est disponible';
$_MODULE['<{blockpaymentlogo}leo_hitechgame>blockpaymentlogo_f4f70727dc34561dfde1a3c529b6205c'] = 'Réglages';
$_MODULE['<{blockpaymentlogo}leo_hitechgame>blockpaymentlogo_829cb250498661a9f98a58dc670a9675'] = 'Page de destination pour le lien du bloc';
$_MODULE['<{blockpaymentlogo}leo_hitechgame>blockpaymentlogo_c9cc8cce247e49bae79f15173ce97354'] = 'Enregistrer';
$_MODULE['<{blockpaymentlogo}leo_hitechgame>blockpaymentlogo_b13fca921e8a4547cf90ca42a8b68b8a'] = 'Nous acceptons';
