<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockpaymentlogo}leo_hitechgame>blockpaymentlogo_eaaf494f0c90a2707d768a9df605e94b'] = 'Logos de pagamento bloco';
$_MODULE['<{blockpaymentlogo}leo_hitechgame>blockpaymentlogo_3fd11fa0ede1bd0ace9b3fcdbf6a71c9'] = 'Adiciona um Bloco com seus logotipos de pagamento.';
$_MODULE['<{blockpaymentlogo}leo_hitechgame>blockpaymentlogo_b15e7271053fe9dd22d80db100179085'] = 'Este módulo precisa ser ligado em uma coluna e seu tema não implementa nenhuma.';
$_MODULE['<{blockpaymentlogo}leo_hitechgame>blockpaymentlogo_efc226b17e0532afff43be870bff0de7'] = 'Configurações atualizadas';
$_MODULE['<{blockpaymentlogo}leo_hitechgame>blockpaymentlogo_5c5e5371da7ab2c28d1af066a1a1cc0d'] = 'Nenhuma página CMS disponível';
$_MODULE['<{blockpaymentlogo}leo_hitechgame>blockpaymentlogo_f4f70727dc34561dfde1a3c529b6205c'] = 'Configurações';
$_MODULE['<{blockpaymentlogo}leo_hitechgame>blockpaymentlogo_829cb250498661a9f98a58dc670a9675'] = 'Página de destino para o link do bloco ';
$_MODULE['<{blockpaymentlogo}leo_hitechgame>blockpaymentlogo_c9cc8cce247e49bae79f15173ce97354'] = 'Salvar';
$_MODULE['<{blockpaymentlogo}leo_hitechgame>blockpaymentlogo_b13fca921e8a4547cf90ca42a8b68b8a'] = 'Aceitamos';
