<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{gridhtml}leo_hitechgame>gridhtml_cf6b972204ee563b4e5691b293e931b6'] = 'Exibir tabela em HTML simples';
$_MODULE['<{gridhtml}leo_hitechgame>gridhtml_05ce5a49b49dd6245f71e384c4b43564'] = 'Permite que o sistema de estatísticas apresente informações em uma grade.';
