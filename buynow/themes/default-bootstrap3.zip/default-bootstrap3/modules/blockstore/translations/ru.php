<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockstore}leo_hitechgame>blockstore_68e9ecb0ab69b1121fe06177868b8ade'] = 'Блок пунктов выдачи';
$_MODULE['<{blockstore}leo_hitechgame>blockstore_c1104fe0bdaceb2e1c6f77b04977b64b'] = 'Отображает ссылку изображения в функции магазин локатора PrestaShop автора.';
$_MODULE['<{blockstore}leo_hitechgame>blockstore_b786bfc116ecf9a6d47ce1114ca6abb7'] = 'Этот модуль должен быть закреплен в колонне, но ваш шаблон eе не предоставляет.';
$_MODULE['<{blockstore}leo_hitechgame>blockstore_7107f6f679c8d8b21ef6fce56fef4b93'] = 'Неверный изображения.';
$_MODULE['<{blockstore}leo_hitechgame>blockstore_df7859ac16e724c9b1fba0a364503d72'] = 'Произошла ошибка при попытке загрузить файл.';
$_MODULE['<{blockstore}leo_hitechgame>blockstore_efc226b17e0532afff43be870bff0de7'] = 'Настройки были обновлены.';
$_MODULE['<{blockstore}leo_hitechgame>blockstore_f4f70727dc34561dfde1a3c529b6205c'] = 'Настройки';
$_MODULE['<{blockstore}leo_hitechgame>blockstore_4d100d8b1b9bcb5a376f78365340cdbe'] = 'Изображение блока \"Адреса магазинов\"';
$_MODULE['<{blockstore}leo_hitechgame>blockstore_a34202cc413553fe0fe2d46f706db435'] = 'Текст блока \"Адреса магазинов\"';
$_MODULE['<{blockstore}leo_hitechgame>blockstore_c9cc8cce247e49bae79f15173ce97354'] = 'Экономить';
$_MODULE['<{blockstore}leo_hitechgame>blockstore_8c0caec5616160618b362bcd4427d97b'] = 'Наши магазины';
$_MODULE['<{blockstore}leo_hitechgame>blockstore_28fe12f949fd191685071517628df9b3'] = 'Артикул, по убыванию';
$_MODULE['<{blockstore}leo_hitechgame>blockstore_34c869c542dee932ef8cd96d2f91cae6'] = 'Наши магазины';
$_MODULE['<{blockstore}leo_hitechgame>blockstore_61d5070a61ce6eb6ad2a212fdf967d92'] = 'Найти наши магазины';
