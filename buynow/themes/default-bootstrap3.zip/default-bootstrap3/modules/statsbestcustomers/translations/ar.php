<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{statsbestcustomers}leo_hitechgame>statsbestcustomers_4f29d8c727dcf2022ac241cb96c31083'] = 'سجلات فارغة عاد';
$_MODULE['<{statsbestcustomers}leo_hitechgame>statsbestcustomers_f5c493141bb4b2508c5938fd9353291a'] = 'عرض٪ 1 $ s من٪ 2 $ S';
$_MODULE['<{statsbestcustomers}leo_hitechgame>statsbestcustomers_77587239bf4c54ea493c7033e1dbf636'] = 'الاسم الأخير';
$_MODULE['<{statsbestcustomers}leo_hitechgame>statsbestcustomers_bc910f8bdf70f29374f496f05be0330c'] = 'الاسم الأول';
$_MODULE['<{statsbestcustomers}leo_hitechgame>statsbestcustomers_ce8ae9da5b7cd6c3df2929543a9af92d'] = 'البريد الإلكتروني';
$_MODULE['<{statsbestcustomers}leo_hitechgame>statsbestcustomers_d7e637a6e9ff116de2fa89551240a94d'] = 'الزيارات';
$_MODULE['<{statsbestcustomers}leo_hitechgame>statsbestcustomers_ec1ee973b8947391f8f014c76ac7379f'] = 'طلبات شراء صحيحة:';
$_MODULE['<{statsbestcustomers}leo_hitechgame>statsbestcustomers_1ff1b62d08d1195f073c6adac00f1894'] = 'إنفاق الأموال';
$_MODULE['<{statsbestcustomers}leo_hitechgame>statsbestcustomers_8b83489bd116cb60e2f348e9c63cd7f6'] = 'أفضل العملاء';
$_MODULE['<{statsbestcustomers}leo_hitechgame>statsbestcustomers_9a1643c70b51526dd35d546ef8e17b87'] = 'يضيف قائمة أفضل العملاء إلى لوحة القيادة الإحصائيات.';
$_MODULE['<{statsbestcustomers}leo_hitechgame>statsbestcustomers_6602bbeb2956c035fb4cb5e844a4861b'] = 'المعالج';
$_MODULE['<{statsbestcustomers}leo_hitechgame>statsbestcustomers_cb21e843b037359d0fb5b793fccf964f'] = 'تطوير ولاء العملاء';
$_MODULE['<{statsbestcustomers}leo_hitechgame>statsbestcustomers_c01d21a09f02b8e661114db60a0f60d4'] = 'يمكن الحفاظ على العميل أن تكون أكثر ربحية من كسب واحدة جديدة. التي هي واحدة من أسباب كثيرة كان من الضروري زراعة ولاء العملاء.';
$_MODULE['<{statsbestcustomers}leo_hitechgame>statsbestcustomers_197bad7ad08abfd1dc45ab92f96f155d'] = 'كلمة في الفم هو أيضا وسيلة للحصول على جديد، العملاء بالارتياح. A العملاء غير راضين يمكن ان تؤذي سمعة-الإلكتروني الخاص بك وعرقلة أهداف المبيعات في المستقبل.';
$_MODULE['<{statsbestcustomers}leo_hitechgame>statsbestcustomers_bf0d87b5aa8d331563ee61f2ac82069d'] = 'من أجل تحقيق هذا الهدف يمكن تنظيم :';
$_MODULE['<{statsbestcustomers}leo_hitechgame>statsbestcustomers_397a5e109a5897ee7d699050cbc93347'] = 'العمليات في الوقت المحدد: مكافآت التجارية (عروض خاصة شخصية أو منتج أو الخدمة المقدمة)، والمكافآت غير التجارية (التعامل مع الأولوية أمر أو المنتج)، والمكافآت مالية (سندات وكوبونات الخصم، السداد).';
$_MODULE['<{statsbestcustomers}leo_hitechgame>statsbestcustomers_4bc24eed56e0ba89fc3ab4e094d18d8a'] = 'العمليات المستدامة: نقاط الولاء أو البطاقات، والتي تبرر ليس فقط التواصل بين التاجر والعميل، ولكن أيضا توفر مزايا للعملاء (العروض الخاصة والخصومات).';
$_MODULE['<{statsbestcustomers}leo_hitechgame>statsbestcustomers_2f408c42912e3afe23a0e4adcbe34b96'] = 'هذه العمليات تشجيع العملاء لشراء المنتجات وزيارة متجر على الانترنت أكثر انتظاما.';
$_MODULE['<{statsbestcustomers}leo_hitechgame>statsbestcustomers_998e4c5c80f27dec552e99dfed34889a'] = 'إستيراد ملف إعدادات';
