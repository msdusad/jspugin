<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{statsbestcustomers}leo_hitechgame>statsbestcustomers_4f29d8c727dcf2022ac241cb96c31083'] = 'Recordset vuoto restituito';
$_MODULE['<{statsbestcustomers}leo_hitechgame>statsbestcustomers_f5c493141bb4b2508c5938fd9353291a'] = 'Visualizzazione %1$s di %2$s';
$_MODULE['<{statsbestcustomers}leo_hitechgame>statsbestcustomers_77587239bf4c54ea493c7033e1dbf636'] = 'Cognome';
$_MODULE['<{statsbestcustomers}leo_hitechgame>statsbestcustomers_bc910f8bdf70f29374f496f05be0330c'] = 'Nome';
$_MODULE['<{statsbestcustomers}leo_hitechgame>statsbestcustomers_ce8ae9da5b7cd6c3df2929543a9af92d'] = 'Email';
$_MODULE['<{statsbestcustomers}leo_hitechgame>statsbestcustomers_d7e637a6e9ff116de2fa89551240a94d'] = 'Visite';
$_MODULE['<{statsbestcustomers}leo_hitechgame>statsbestcustomers_ec1ee973b8947391f8f014c76ac7379f'] = 'Ordini validi';
$_MODULE['<{statsbestcustomers}leo_hitechgame>statsbestcustomers_1ff1b62d08d1195f073c6adac00f1894'] = 'Denaro speso';
$_MODULE['<{statsbestcustomers}leo_hitechgame>statsbestcustomers_8b83489bd116cb60e2f348e9c63cd7f6'] = 'Migliori clienti';
$_MODULE['<{statsbestcustomers}leo_hitechgame>statsbestcustomers_9a1643c70b51526dd35d546ef8e17b87'] = 'Aggiunge una lista dei migliori clienti al cruscotto statistiche.';
$_MODULE['<{statsbestcustomers}leo_hitechgame>statsbestcustomers_6602bbeb2956c035fb4cb5e844a4861b'] = 'Guida';
$_MODULE['<{statsbestcustomers}leo_hitechgame>statsbestcustomers_cb21e843b037359d0fb5b793fccf964f'] = 'Sviluppa la fedeltà dei clienti';
$_MODULE['<{statsbestcustomers}leo_hitechgame>statsbestcustomers_c01d21a09f02b8e661114db60a0f60d4'] = 'Mantenere un client può essere più redditizio di guadagnare uno nuovo. Questo è uno dei tanti motivi è necessario coltivare la fedeltà del cliente.';
$_MODULE['<{statsbestcustomers}leo_hitechgame>statsbestcustomers_197bad7ad08abfd1dc45ab92f96f155d'] = 'Il passaparola è anche un mezzo per ottenere nuovi clienti soddisfatti; un cliente non soddisfatto non attirerà nuovi clienti.';
$_MODULE['<{statsbestcustomers}leo_hitechgame>statsbestcustomers_bf0d87b5aa8d331563ee61f2ac82069d'] = 'Al fine di raggiungere questo obiettivo è possibile organizzare:';
$_MODULE['<{statsbestcustomers}leo_hitechgame>statsbestcustomers_397a5e109a5897ee7d699050cbc93347'] = 'Operazioni puntuali: premi commerciali (offerte speciali personalizzate, prodotto o servizio offerto), premi non commerciale (gestione prioritaria di un ordine o un prodotto), premi pecuniari (obbligazioni, buoni sconto, ...).';
$_MODULE['<{statsbestcustomers}leo_hitechgame>statsbestcustomers_4bc24eed56e0ba89fc3ab4e094d18d8a'] = 'operazioni sostenibili: le carte fedeltà o punti, che non solo giustificano la comunicazione tra commerciante e cliente, ma offre anche vantaggi ai clienti (offerte private, sconti).';
$_MODULE['<{statsbestcustomers}leo_hitechgame>statsbestcustomers_2f408c42912e3afe23a0e4adcbe34b96'] = 'Queste operazioni incoraggiano i clienti di acquistare prodotti e visitare il vostro negozio online più regolarmente.';
$_MODULE['<{statsbestcustomers}leo_hitechgame>statsbestcustomers_998e4c5c80f27dec552e99dfed34889a'] = 'CSV Export';
