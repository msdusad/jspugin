<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{leocustomajax}leo_hitechgame>cdown_545f6c2f382c04810103b3e5e6f7d841'] = 'Неограниченный';
$_MODULE['<{leocustomajax}leo_hitechgame>leocustomajax_048db14395aeb0b3cda64df23385016a'] = 'Лев Пользовательские Аякс';
$_MODULE['<{leocustomajax}leo_hitechgame>leocustomajax_20403cc83f2cbe11ce1cc7f1a411cc7b'] = 'Показать номер продукта категории и шоу-рейтинге.';
$_MODULE['<{leocustomajax}leo_hitechgame>leocustomajax_3384b8f35897040e4d82ee1f0e5861b9'] = 'Входная строка не является правильным.';
$_MODULE['<{leocustomajax}leo_hitechgame>leocustomajax_6af91e35dff67a43ace060d1d57d5d1a'] = 'Ваши настройки были обновлены.';
$_MODULE['<{leocustomajax}leo_hitechgame>leocustomajax_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Включено';
$_MODULE['<{leocustomajax}leo_hitechgame>leocustomajax_b9f5c797ebbf55adccdd8539a65a0241'] = 'Инвалид';
$_MODULE['<{leocustomajax}leo_hitechgame>leocustomajax_f4f70727dc34561dfde1a3c529b6205c'] = 'Настройки';
$_MODULE['<{leocustomajax}leo_hitechgame>leocustomajax_c9cc8cce247e49bae79f15173ce97354'] = 'Экономить';
$_MODULE['<{leocustomajax}leo_hitechgame>leocustomajax_24fe48030f7d3097d5882535b04c3fa8'] = 'Истекло';
$_MODULE['<{leocustomajax}leo_hitechgame>leocustomajax_545f6c2f382c04810103b3e5e6f7d841'] = 'Неограниченный';
$_MODULE['<{leocustomajax}leo_hitechgame>product_9981d2af851e4b4a4ea612d59f08ab9c'] = 'Other views';
