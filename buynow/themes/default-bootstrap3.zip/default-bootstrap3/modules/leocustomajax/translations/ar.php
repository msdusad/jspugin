<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{leocustomajax}leo_hitechgame>cdown_545f6c2f382c04810103b3e5e6f7d841'] = 'غير محدود';
$_MODULE['<{leocustomajax}leo_hitechgame>leocustomajax_048db14395aeb0b3cda64df23385016a'] = 'ليو مخصص أياكس';
$_MODULE['<{leocustomajax}leo_hitechgame>leocustomajax_20403cc83f2cbe11ce1cc7f1a411cc7b'] = 'عرض عدد من المنتجات وتظهر فئة التصنيف.';
$_MODULE['<{leocustomajax}leo_hitechgame>leocustomajax_3384b8f35897040e4d82ee1f0e5861b9'] = 'سلسلة الإدخال غير صحيح.';
$_MODULE['<{leocustomajax}leo_hitechgame>leocustomajax_6af91e35dff67a43ace060d1d57d5d1a'] = 'تم تحديث الإعدادات الخاصة بك.';
$_MODULE['<{leocustomajax}leo_hitechgame>leocustomajax_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'تمكين';
$_MODULE['<{leocustomajax}leo_hitechgame>leocustomajax_b9f5c797ebbf55adccdd8539a65a0241'] = 'معاق';
$_MODULE['<{leocustomajax}leo_hitechgame>leocustomajax_f4f70727dc34561dfde1a3c529b6205c'] = 'إعدادات';
$_MODULE['<{leocustomajax}leo_hitechgame>leocustomajax_c9cc8cce247e49bae79f15173ce97354'] = 'حفظ';
$_MODULE['<{leocustomajax}leo_hitechgame>leocustomajax_24fe48030f7d3097d5882535b04c3fa8'] = 'انتهت';
$_MODULE['<{leocustomajax}leo_hitechgame>leocustomajax_545f6c2f382c04810103b3e5e6f7d841'] = 'غير محدود';
$_MODULE['<{leocustomajax}leo_hitechgame>product_9981d2af851e4b4a4ea612d59f08ab9c'] = 'Other views';
