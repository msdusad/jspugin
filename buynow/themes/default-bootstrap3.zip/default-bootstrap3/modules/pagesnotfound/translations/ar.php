<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{pagesnotfound}leo_hitechgame>pagesnotfound_251295238bdf7693252f2804c8d3707e'] = 'صفحات لم يتم العثور على';
$_MODULE['<{pagesnotfound}leo_hitechgame>pagesnotfound_607cc8b8993662a37cac86032fb071d2'] = 'يضيف علامة تبويب إلى لوحة القيادة الإحصائيات، والتي تبين من خلال صفحات زوارك طلب التي لم يتم العثور عليها.';
$_MODULE['<{pagesnotfound}leo_hitechgame>pagesnotfound_dc3a3db6b98723bf91f924537a630600'] = 'و\"لم يتم العثور على صفحات\" تم تفريغ ذاكرة التخزين المؤقت.';
$_MODULE['<{pagesnotfound}leo_hitechgame>pagesnotfound_b323790d8ee3c43d317d19aea5012626'] = 'و\"لم يتم العثور على صفحات\" تم حذف ذاكرة التخزين المؤقت.';
$_MODULE['<{pagesnotfound}leo_hitechgame>pagesnotfound_6602bbeb2956c035fb4cb5e844a4861b'] = 'المعالج';
$_MODULE['<{pagesnotfound}leo_hitechgame>pagesnotfound_3604249130acf7fda296e16edc996e5b'] = '404 أخطاء';
$_MODULE['<{pagesnotfound}leo_hitechgame>pagesnotfound_675f1f46497aeeee35832a5d9d095976'] = 'خطأ 404 هو رمز خطأ HTTP وهو ما يعني أن الملف من قبل المستخدم المطلوبة لا يمكن العثور عليه. في حالتك فهذا يعني أن واحدا من زوار موقعك دخلت URL الخطأ في شريط العنوان، أو أنك أو موقع آخر له صلة مكسورة. عندما يكون ذلك ممكنا، يظهر المرجع حتى تتمكن من العثور على الصفحة / الموقع الذي يحتوي على وصلة مكسورة. إذا لم يكن كذلك، فهذا يعني عموما أنه هو الوصول المباشر، لذلك شخص قد إشارة مرجعية وصلة التي لا وجود لها بعد الآن.';
$_MODULE['<{pagesnotfound}leo_hitechgame>pagesnotfound_a90083861c168ef985bf70763980aa60'] = 'كيفية التقاط هذه الأخطاء؟';
$_MODULE['<{pagesnotfound}leo_hitechgame>pagesnotfound_4f803d59ee120b11662027e049cba1f3'] = '. إذا يدعم الإستضافة الخاصة بك htaccess الملفات، يمكنك إنشاء واحد في الدليل الجذر من بريستاشوب وإدراج السطر التالي داخل: \"٪ S\".';
$_MODULE['<{pagesnotfound}leo_hitechgame>pagesnotfound_07e7f83ae625fe216a644d09feab4573'] = 'سيتم إعادة توجيه المستخدم طلب الصفحة التي لا وجود لها على الصفحة التالية:٪ ق. هذه الوحدة بتسجيل الوصول إلى هذه الصفحة.';
$_MODULE['<{pagesnotfound}leo_hitechgame>pagesnotfound_01bd0bf7c5a68ad6ee4423118be3f7b6'] = 'يجب عليك استخدام ملف هتكس. لإعادة توجيه 404 أخطاء لصفحة \"404.php\".';
$_MODULE['<{pagesnotfound}leo_hitechgame>pagesnotfound_193cfc9be3b995831c6af2fea6650e60'] = 'الصفحة';
$_MODULE['<{pagesnotfound}leo_hitechgame>pagesnotfound_b6f05e5ddde1ec63d992d61144452dfa'] = 'المرجع';
$_MODULE['<{pagesnotfound}leo_hitechgame>pagesnotfound_64d129224a5377b63e9727479ec987d9'] = 'عداد';
$_MODULE['<{pagesnotfound}leo_hitechgame>pagesnotfound_4a7a7e7cda40454cee7ec247660f8017'] = 'لا \"الصفحة غير موجودة\" قضية مسجلة في الوقت الراهن.';
$_MODULE['<{pagesnotfound}leo_hitechgame>pagesnotfound_d8847bc418fc4f5a3e37c2e8390bb9ed'] = 'قاعدة بيانات فارغة';
$_MODULE['<{pagesnotfound}leo_hitechgame>pagesnotfound_b9ae3636d6e672413a163f7cb34beb84'] = 'ALL فارغة \"صفحة لم يتم العثور على\" إشعارات لهذه الفترة';
$_MODULE['<{pagesnotfound}leo_hitechgame>pagesnotfound_0cf5c3a279c0e8c57b232d8c6bc3f06a'] = 'ALL فارغة \"صفحة لم يتم العثور على\" إشعارات';
