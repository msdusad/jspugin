<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{pagesnotfound}leo_hitechgame>pagesnotfound_251295238bdf7693252f2804c8d3707e'] = 'Página não encontrada';
$_MODULE['<{pagesnotfound}leo_hitechgame>pagesnotfound_607cc8b8993662a37cac86032fb071d2'] = 'Adiciona um separador ao Stats painel, mostrando as páginas solicitadas pelos visitantes que não tenham sido encontradas.';
$_MODULE['<{pagesnotfound}leo_hitechgame>pagesnotfound_dc3a3db6b98723bf91f924537a630600'] = 'O cache das \"Páginas não encontradas\" foi esvaziado.';
$_MODULE['<{pagesnotfound}leo_hitechgame>pagesnotfound_b323790d8ee3c43d317d19aea5012626'] = 'As \"páginas não encontrado\" cache foi excluído.';
$_MODULE['<{pagesnotfound}leo_hitechgame>pagesnotfound_6602bbeb2956c035fb4cb5e844a4861b'] = 'Guia';
$_MODULE['<{pagesnotfound}leo_hitechgame>pagesnotfound_3604249130acf7fda296e16edc996e5b'] = 'erros 404';
$_MODULE['<{pagesnotfound}leo_hitechgame>pagesnotfound_675f1f46497aeeee35832a5d9d095976'] = 'Um erro 404 é um código de erro HTTP, o que significa que o arquivo solicitado pelo usuário não pode ser encontrado. No seu caso, isso significa que um de seus visitantes entraram em um URL errado na barra de endereços, ou que você ou outro site tem um link morto. Quando possível, a referência é mostrada para que você possa encontrar a página / site, que contém o link morto. Se não, ele geralmente significa que é um acesso direto, então alguém pode ter marcado um link que não existe mais.';
$_MODULE['<{pagesnotfound}leo_hitechgame>pagesnotfound_a90083861c168ef985bf70763980aa60'] = 'Como capturar esses erros?';
$_MODULE['<{pagesnotfound}leo_hitechgame>pagesnotfound_4f803d59ee120b11662027e049cba1f3'] = 'Se o seu serviço de hospedagem suporta o arquivo .htaccess, você pode criá-lo no diretório raiz do PrestaShop e inserir a seguinte linha no interior do arquivo: \"%s\".';
$_MODULE['<{pagesnotfound}leo_hitechgame>pagesnotfound_07e7f83ae625fe216a644d09feab4573'] = 'Um usuário que tenha requisitado uma página que não existe será redirecionado para a seguinte página: %s. Este módulo registra o acesso a esta página.';
$_MODULE['<{pagesnotfound}leo_hitechgame>pagesnotfound_01bd0bf7c5a68ad6ee4423118be3f7b6'] = 'Você deve usar um arquivo htaccess. Redirecionar erros 404 para a página de \"404.php\".';
$_MODULE['<{pagesnotfound}leo_hitechgame>pagesnotfound_193cfc9be3b995831c6af2fea6650e60'] = 'Página';
$_MODULE['<{pagesnotfound}leo_hitechgame>pagesnotfound_b6f05e5ddde1ec63d992d61144452dfa'] = 'Referência';
$_MODULE['<{pagesnotfound}leo_hitechgame>pagesnotfound_64d129224a5377b63e9727479ec987d9'] = 'Contador';
$_MODULE['<{pagesnotfound}leo_hitechgame>pagesnotfound_4a7a7e7cda40454cee7ec247660f8017'] = 'No \"página não encontrada\" questão registrado por agora.';
$_MODULE['<{pagesnotfound}leo_hitechgame>pagesnotfound_d8847bc418fc4f5a3e37c2e8390bb9ed'] = 'Esvaziar banco de dados';
$_MODULE['<{pagesnotfound}leo_hitechgame>pagesnotfound_b9ae3636d6e672413a163f7cb34beb84'] = 'Esvazie as \"páginas não encontrado\" avisos para este período';
$_MODULE['<{pagesnotfound}leo_hitechgame>pagesnotfound_0cf5c3a279c0e8c57b232d8c6bc3f06a'] = 'Esvazie as \"páginas não encontrado\" Avisos';
