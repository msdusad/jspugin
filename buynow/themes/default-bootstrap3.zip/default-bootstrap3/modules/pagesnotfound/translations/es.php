<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{pagesnotfound}leo_hitechgame>pagesnotfound_251295238bdf7693252f2804c8d3707e'] = 'Página no encontrada';
$_MODULE['<{pagesnotfound}leo_hitechgame>pagesnotfound_607cc8b8993662a37cac86032fb071d2'] = 'Añadir una pestaña a la tabla de estadísticas, mostrando las páginas solicitadas por tus visitantes que no han encontrado.';
$_MODULE['<{pagesnotfound}leo_hitechgame>pagesnotfound_dc3a3db6b98723bf91f924537a630600'] = 'Páginas no encontradas suprimidas.';
$_MODULE['<{pagesnotfound}leo_hitechgame>pagesnotfound_b323790d8ee3c43d317d19aea5012626'] = 'La caché de \"páginas no encontradas\" se ha eliminado.';
$_MODULE['<{pagesnotfound}leo_hitechgame>pagesnotfound_6602bbeb2956c035fb4cb5e844a4861b'] = 'Guía';
$_MODULE['<{pagesnotfound}leo_hitechgame>pagesnotfound_3604249130acf7fda296e16edc996e5b'] = 'error 404';
$_MODULE['<{pagesnotfound}leo_hitechgame>pagesnotfound_675f1f46497aeeee35832a5d9d095976'] = 'Un error 404 es un código de error HTTP que significa que el archivo solicitado por el usuario no se puede encontrar. En su caso esto significa que uno de sus visitantes introducido una URL incorrecta en la barra de direcciones, o que usted u otro sitio web tiene un vínculo roto. Cuando sea posible, se muestra el referente para que pueda encontrar la página / sitio que contiene el vínculo roto. Si no, por lo general significa que se trata de un acceso directo, por lo que alguien pudo haber marcado un vínculo que no existe más.';
$_MODULE['<{pagesnotfound}leo_hitechgame>pagesnotfound_a90083861c168ef985bf70763980aa60'] = '¿Como prevenir estos errores?';
$_MODULE['<{pagesnotfound}leo_hitechgame>pagesnotfound_4f803d59ee120b11662027e049cba1f3'] = 'Si tu servidor es compatible con archivos .htaccess, puedes crear un directorio raíz de PrestaShop e insertar la siguiente línea en el interior: \"%s\".';
$_MODULE['<{pagesnotfound}leo_hitechgame>pagesnotfound_07e7f83ae625fe216a644d09feab4573'] = 'Se le restringirá el acceso a los usuarios que soliciten una página inexistente a: %s. Este módulo registra accesos a esta página.';
$_MODULE['<{pagesnotfound}leo_hitechgame>pagesnotfound_01bd0bf7c5a68ad6ee4423118be3f7b6'] = 'Debes utilizar un archivo .htaccess para redirigir los errores 404 a la página \"404.php\".';
$_MODULE['<{pagesnotfound}leo_hitechgame>pagesnotfound_193cfc9be3b995831c6af2fea6650e60'] = 'Página';
$_MODULE['<{pagesnotfound}leo_hitechgame>pagesnotfound_b6f05e5ddde1ec63d992d61144452dfa'] = 'origen';
$_MODULE['<{pagesnotfound}leo_hitechgame>pagesnotfound_64d129224a5377b63e9727479ec987d9'] = 'Contador';
$_MODULE['<{pagesnotfound}leo_hitechgame>pagesnotfound_4a7a7e7cda40454cee7ec247660f8017'] = 'No se ha registrado ningún \"página no encontrada\" por ahora.';
$_MODULE['<{pagesnotfound}leo_hitechgame>pagesnotfound_d8847bc418fc4f5a3e37c2e8390bb9ed'] = 'Suprimir';
$_MODULE['<{pagesnotfound}leo_hitechgame>pagesnotfound_b9ae3636d6e672413a163f7cb34beb84'] = 'Vaciar TODOS los avisos de \"páginas no encontradas\" de este periodo';
$_MODULE['<{pagesnotfound}leo_hitechgame>pagesnotfound_0cf5c3a279c0e8c57b232d8c6bc3f06a'] = 'Vaciar TODOS los avisos de \"páginas no encontradas\"';
