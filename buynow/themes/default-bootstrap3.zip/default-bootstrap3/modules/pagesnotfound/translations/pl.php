<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{pagesnotfound}leo_hitechgame>pagesnotfound_251295238bdf7693252f2804c8d3707e'] = 'Strony nie znalezione';
$_MODULE['<{pagesnotfound}leo_hitechgame>pagesnotfound_607cc8b8993662a37cac86032fb071d2'] = 'Dodaje zakładkę do panelu Statystyk, pokazującą strony wywoływane przez odwiedzających które nie zostały odnalezione.';
$_MODULE['<{pagesnotfound}leo_hitechgame>pagesnotfound_dc3a3db6b98723bf91f924537a630600'] = 'Bufor \"Nie znaleziono strony\" zostanie opróżniony.';
$_MODULE['<{pagesnotfound}leo_hitechgame>pagesnotfound_b323790d8ee3c43d317d19aea5012626'] = 'Bufor \"Nie znaleziono strony\" został opróżniony.';
$_MODULE['<{pagesnotfound}leo_hitechgame>pagesnotfound_6602bbeb2956c035fb4cb5e844a4861b'] = 'Poradnik';
$_MODULE['<{pagesnotfound}leo_hitechgame>pagesnotfound_3604249130acf7fda296e16edc996e5b'] = 'Błędy 404';
$_MODULE['<{pagesnotfound}leo_hitechgame>pagesnotfound_675f1f46497aeeee35832a5d9d095976'] = '404 błąd jest kod błędu HTTP, co oznacza, że ​​wymagane przez użytkownika pliku nie można znaleźć. W twoim przypadku oznacza to, że jeden z użytkowników Niepoprawny adres URL w pasku adresu, albo, że ty lub inna strona ma niedziałający link. Jeśli to możliwe, wywołującej pokazano więc można znaleźć stronę / strony, która zawiera niedziałający link. Jeśli nie, oznacza to zwykle, że jest bezpośredni dostęp, więc ktoś mógł zakładki link, który już nie ma.';
$_MODULE['<{pagesnotfound}leo_hitechgame>pagesnotfound_a90083861c168ef985bf70763980aa60'] = 'Jak przechwytywać te błędy?';
$_MODULE['<{pagesnotfound}leo_hitechgame>pagesnotfound_4f803d59ee120b11662027e049cba1f3'] = 'Jeśli webhost wspiera plik .htaccess, możesz go utworzyć w katalogu głównym PrestaShop i wstawić następujący wiersz wewnątrz: \"%s\".';
$_MODULE['<{pagesnotfound}leo_hitechgame>pagesnotfound_07e7f83ae625fe216a644d09feab4573'] = 'Użytkownik wywołujący stronę, która nie istnieje zostanie przekierowany na następującą stronę: %s. Ten moduł zapisuje logi z dostępu do tej strony.';
$_MODULE['<{pagesnotfound}leo_hitechgame>pagesnotfound_01bd0bf7c5a68ad6ee4423118be3f7b6'] = 'Musisz użyć pliku .htaccess aby przekierować błedy 404 na stronę \"404.php\".';
$_MODULE['<{pagesnotfound}leo_hitechgame>pagesnotfound_193cfc9be3b995831c6af2fea6650e60'] = 'Strona';
$_MODULE['<{pagesnotfound}leo_hitechgame>pagesnotfound_b6f05e5ddde1ec63d992d61144452dfa'] = 'Odwołujący (Referrer)';
$_MODULE['<{pagesnotfound}leo_hitechgame>pagesnotfound_64d129224a5377b63e9727479ec987d9'] = 'Licznik';
$_MODULE['<{pagesnotfound}leo_hitechgame>pagesnotfound_4a7a7e7cda40454cee7ec247660f8017'] = 'Nie \"nie znaleziono strony\" problem zarejestrowany na teraz.';
$_MODULE['<{pagesnotfound}leo_hitechgame>pagesnotfound_d8847bc418fc4f5a3e37c2e8390bb9ed'] = 'Pusta baza danych';
$_MODULE['<{pagesnotfound}leo_hitechgame>pagesnotfound_b9ae3636d6e672413a163f7cb34beb84'] = 'Puste ALL \"nie znaleziono strony\" Anonse dla tego okresu';
$_MODULE['<{pagesnotfound}leo_hitechgame>pagesnotfound_0cf5c3a279c0e8c57b232d8c6bc3f06a'] = 'Puste ALL \"nie znaleziono strony\" Anonse';
