<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{pagesnotfound}leo_hitechgame>pagesnotfound_251295238bdf7693252f2804c8d3707e'] = 'Pagine non trovate';
$_MODULE['<{pagesnotfound}leo_hitechgame>pagesnotfound_607cc8b8993662a37cac86032fb071d2'] = 'Aggiunge una scheda per il cruscotto Stats, mostrando le pagine richieste dai visitatori che non sono stati trovati.';
$_MODULE['<{pagesnotfound}leo_hitechgame>pagesnotfound_dc3a3db6b98723bf91f924537a630600'] = 'Le \"pagine non trovata\" cache è stato svuotato.';
$_MODULE['<{pagesnotfound}leo_hitechgame>pagesnotfound_b323790d8ee3c43d317d19aea5012626'] = 'Le \"pagine non trovata\" cache è stato cancellato.';
$_MODULE['<{pagesnotfound}leo_hitechgame>pagesnotfound_6602bbeb2956c035fb4cb5e844a4861b'] = 'Guida';
$_MODULE['<{pagesnotfound}leo_hitechgame>pagesnotfound_3604249130acf7fda296e16edc996e5b'] = 'errori 404';
$_MODULE['<{pagesnotfound}leo_hitechgame>pagesnotfound_675f1f46497aeeee35832a5d9d095976'] = 'Un errore 404 è un codice di errore HTTP che significa che il file richiesto dall\'utente non può essere trovato. Nel tuo caso significa che uno dei tuoi visitatori ha digitato un\'URL errata nella barra degli indirizzi o che il tuo o un altro sito web ha un link morto. Quando possibile è visualizzato il referrer, così che tu possa trovare la pagina e il sito che contiene il link morto. Altrimenti, in genere significa che si tratta di un accesso diretto, dunque qualcuno ha messo tra i preferiti un link non più esistente.';
$_MODULE['<{pagesnotfound}leo_hitechgame>pagesnotfound_a90083861c168ef985bf70763980aa60'] = 'Come individuare questi errori?';
$_MODULE['<{pagesnotfound}leo_hitechgame>pagesnotfound_4f803d59ee120b11662027e049cba1f3'] = 'Se il tuo hosting supporta i files .htaccess, puoi crearne uno nella directory principale di PrestaShop e inserirvi dentro la seguente riga: \"%s\".';
$_MODULE['<{pagesnotfound}leo_hitechgame>pagesnotfound_07e7f83ae625fe216a644d09feab4573'] = 'Un utente che ha richiesto una pagina inesistente verrà reindirizzato alla pagina seguente: %s. Questo modulo registra gli accessi a questa pagina.';
$_MODULE['<{pagesnotfound}leo_hitechgame>pagesnotfound_01bd0bf7c5a68ad6ee4423118be3f7b6'] = 'È necessario utilizzare un file htaccess. Per reindirizzare errori 404 alla pagina \"404.php\".';
$_MODULE['<{pagesnotfound}leo_hitechgame>pagesnotfound_193cfc9be3b995831c6af2fea6650e60'] = 'Pagina';
$_MODULE['<{pagesnotfound}leo_hitechgame>pagesnotfound_b6f05e5ddde1ec63d992d61144452dfa'] = 'Referente';
$_MODULE['<{pagesnotfound}leo_hitechgame>pagesnotfound_64d129224a5377b63e9727479ec987d9'] = 'Contatore';
$_MODULE['<{pagesnotfound}leo_hitechgame>pagesnotfound_4a7a7e7cda40454cee7ec247660f8017'] = 'No \"pagina non trovata\" emissione registrato per ora.';
$_MODULE['<{pagesnotfound}leo_hitechgame>pagesnotfound_d8847bc418fc4f5a3e37c2e8390bb9ed'] = 'database vuoto';
$_MODULE['<{pagesnotfound}leo_hitechgame>pagesnotfound_b9ae3636d6e672413a163f7cb34beb84'] = 'Svuotare tutti \"pagine non trovata\" avvisi per questo periodo';
$_MODULE['<{pagesnotfound}leo_hitechgame>pagesnotfound_0cf5c3a279c0e8c57b232d8c6bc3f06a'] = 'Svuotare tutti \"pagine non trovata\" avvisi';
