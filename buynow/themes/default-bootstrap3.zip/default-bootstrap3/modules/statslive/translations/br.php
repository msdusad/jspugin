<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{statslive}leo_hitechgame>statslive_fa55230e9791f2b71322869318a5f00f'] = 'Visitantes online';
$_MODULE['<{statslive}leo_hitechgame>statslive_abf306fd198ab007d480ed610a6690fb'] = 'Adiciona uma lista de clientes e visitantes online ao Painel de Estatísticas';
$_MODULE['<{statslive}leo_hitechgame>statslive_85f955e33756b8f40ce35e5b277de5bc'] = 'Você deve ativar a opção \"Salvar páginas vistas para cada cliente\" no módulo \"Mineração de dados para estatísticas\" (StatsData) de forma a ver as páginas que os seus visitantes estão visualizando no momento.';
$_MODULE['<{statslive}leo_hitechgame>statslive_f5ee3b50dba1fb98f1342a584e46cd30'] = 'Visitantes online';
$_MODULE['<{statslive}leo_hitechgame>statslive_66c4c5112f455a19afde47829df363fa'] = 'Total:';
$_MODULE['<{statslive}leo_hitechgame>statslive_d37c2bf1bd3143847fca087b354f920e'] = 'ID do Cliente';
$_MODULE['<{statslive}leo_hitechgame>statslive_49ee3087348e8d44e1feda1917443987'] = 'Nome';
$_MODULE['<{statslive}leo_hitechgame>statslive_13aa8652e950bb7c4b9b213e6d8d0dc5'] = 'Página Atual';
$_MODULE['<{statslive}leo_hitechgame>statslive_9dd3bc54879dc9425d44de81f3d7dfdc'] = 'Ver perfil do cliente';
$_MODULE['<{statslive}leo_hitechgame>statslive_08448d43d8e4b39ad5126d4b06e2f3cc'] = 'Não há nenhum cliente online ativo neste momento.';
$_MODULE['<{statslive}leo_hitechgame>statslive_cf6377279146be659952cea754c558b1'] = 'Visitas atuais online no momento';
$_MODULE['<{statslive}leo_hitechgame>statslive_f8cf0a1a6b03d2b01602992ea273134c'] = 'ID do Visitante';
$_MODULE['<{statslive}leo_hitechgame>statslive_a12a3079e14ced46e69ba52b8a90b21a'] = 'IP';
$_MODULE['<{statslive}leo_hitechgame>statslive_bc5188ca43d423ba3730e4c030609d6e'] = 'Última atividade';
$_MODULE['<{statslive}leo_hitechgame>statslive_b6f05e5ddde1ec63d992d61144452dfa'] = 'Referência';
$_MODULE['<{statslive}leo_hitechgame>statslive_ec0fc0100c4fc1ce4eea230c3dc10360'] = 'Indefinido';
$_MODULE['<{statslive}leo_hitechgame>statslive_6adf97f83acf6453d4a6a4b1070f3754'] = 'nenhum';
$_MODULE['<{statslive}leo_hitechgame>statslive_a55533db46597bee3cd16899c007257e'] = 'Não há visitantes online.';
$_MODULE['<{statslive}leo_hitechgame>statslive_24efa7ee4511563b16144f39706d594f'] = 'Observação';
$_MODULE['<{statslive}leo_hitechgame>statslive_e5900cd9ae26ca607f7cd497f114b9f9'] = 'IPs de Manutenção são excluídos das estatísticas de visitas.';
$_MODULE['<{statslive}leo_hitechgame>statslive_05b564d49dbd9049f0df80a45cfe7d1c'] = 'Adicione ou remova um endereço de IP.';
