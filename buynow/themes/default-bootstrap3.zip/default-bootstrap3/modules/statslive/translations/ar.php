<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{statslive}leo_hitechgame>statslive_fa55230e9791f2b71322869318a5f00f'] = 'الزوار على الانترنت';
$_MODULE['<{statslive}leo_hitechgame>statslive_abf306fd198ab007d480ed610a6690fb'] = 'يضيف قائمة من العملاء والزوار الذين هم على الانترنت للوحة القيادة الإحصائيات حاليا.';
$_MODULE['<{statslive}leo_hitechgame>statslive_85f955e33756b8f40ce35e5b277de5bc'] = 'يجب عليك تفعيل \"مشاهدة صفحة حفظ لكل عميل\" الخيار في \"استخراج البيانات للإحصاءات\" (StatsData) وحدة لتتمكن من مشاهدة الصفحات التي زائرين يشاهدون حاليا.';
$_MODULE['<{statslive}leo_hitechgame>statslive_f5ee3b50dba1fb98f1342a584e46cd30'] = 'العملاء الحاليين على الانترنت';
$_MODULE['<{statslive}leo_hitechgame>statslive_66c4c5112f455a19afde47829df363fa'] = 'الإجمالي:';
$_MODULE['<{statslive}leo_hitechgame>statslive_d37c2bf1bd3143847fca087b354f920e'] = 'رقم تعريف العميل:';
$_MODULE['<{statslive}leo_hitechgame>statslive_49ee3087348e8d44e1feda1917443987'] = 'الاسم';
$_MODULE['<{statslive}leo_hitechgame>statslive_13aa8652e950bb7c4b9b213e6d8d0dc5'] = 'الصفحة الحالية';
$_MODULE['<{statslive}leo_hitechgame>statslive_9dd3bc54879dc9425d44de81f3d7dfdc'] = 'عرض ملف العملاء';
$_MODULE['<{statslive}leo_hitechgame>statslive_08448d43d8e4b39ad5126d4b06e2f3cc'] = 'لا توجد العملاء النشطين على الانترنت في الوقت الحالي.';
$_MODULE['<{statslive}leo_hitechgame>statslive_cf6377279146be659952cea754c558b1'] = 'زوار الموقع الحالي';
$_MODULE['<{statslive}leo_hitechgame>statslive_f8cf0a1a6b03d2b01602992ea273134c'] = 'ID الزوار';
$_MODULE['<{statslive}leo_hitechgame>statslive_a12a3079e14ced46e69ba52b8a90b21a'] = 'IP';
$_MODULE['<{statslive}leo_hitechgame>statslive_bc5188ca43d423ba3730e4c030609d6e'] = 'النشاط الأخير';
$_MODULE['<{statslive}leo_hitechgame>statslive_b6f05e5ddde1ec63d992d61144452dfa'] = 'المرجع';
$_MODULE['<{statslive}leo_hitechgame>statslive_ec0fc0100c4fc1ce4eea230c3dc10360'] = 'غير محدد';
$_MODULE['<{statslive}leo_hitechgame>statslive_6adf97f83acf6453d4a6a4b1070f3754'] = 'لايوجد';
$_MODULE['<{statslive}leo_hitechgame>statslive_a55533db46597bee3cd16899c007257e'] = 'لا توجد زوار الموقع.';
$_MODULE['<{statslive}leo_hitechgame>statslive_24efa7ee4511563b16144f39706d594f'] = 'إشعار';
$_MODULE['<{statslive}leo_hitechgame>statslive_e5900cd9ae26ca607f7cd497f114b9f9'] = 'وتستبعد الشرطة العراقية الصيانة من زوار الإنترنت.';
$_MODULE['<{statslive}leo_hitechgame>statslive_05b564d49dbd9049f0df80a45cfe7d1c'] = 'إضافة أو إزالة عنوان IP.';
