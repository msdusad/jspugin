<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockcmsinfo}leo_hitechgame>blockcmsinfo_988659f6c5d3210a3f085ecfecccf5d3'] = 'Пользовательские CMS Информационный блок';
$_MODULE['<{blockcmsinfo}leo_hitechgame>blockcmsinfo_cd4abd29bdc076fb8fabef674039cd6e'] = 'Добавляет пользовательские информационные блоки в вашем магазине.';
$_MODULE['<{blockcmsinfo}leo_hitechgame>blockcmsinfo_86432715902fbaf53de469fed3fa6c53'] = 'Вы должны выбрать хотя бы один магазин.';
$_MODULE['<{blockcmsinfo}leo_hitechgame>blockcmsinfo_d52eaeff31af37a4a7e0550008aff5df'] = 'Ошибка произошла во время сохранения';
$_MODULE['<{blockcmsinfo}leo_hitechgame>blockcmsinfo_6f16c729fadd8aa164c6c47853983dd2'] = 'Новый пользовательский CMS блок';
$_MODULE['<{blockcmsinfo}leo_hitechgame>blockcmsinfo_9dffbf69ffba8bc38bc4e01abf4b1675'] = 'Тексты';
$_MODULE['<{blockcmsinfo}leo_hitechgame>blockcmsinfo_c9cc8cce247e49bae79f15173ce97354'] = 'Экономить';
$_MODULE['<{blockcmsinfo}leo_hitechgame>blockcmsinfo_630f6dc397fe74e52d5189e2c80f282b'] = 'Назад к списку';
$_MODULE['<{blockcmsinfo}leo_hitechgame>blockcmsinfo_9d55fc80bbb875322aa67fd22fc98469'] = 'Ассоциация магазина';
$_MODULE['<{blockcmsinfo}leo_hitechgame>blockcmsinfo_6fcdef6ca2bb47a0cf61cd41ccf274f4'] = 'ID блока';
$_MODULE['<{blockcmsinfo}leo_hitechgame>blockcmsinfo_9f82518d468b9fee614fcc92f76bb163'] = 'Магазин';
$_MODULE['<{blockcmsinfo}leo_hitechgame>blockcmsinfo_56425383198d22fc8bb296bcca26cecf'] = 'Текстовый блок';
$_MODULE['<{blockcmsinfo}leo_hitechgame>blockcmsinfo_ef61fb324d729c341ea8ab9901e23566'] = 'Добавить';
