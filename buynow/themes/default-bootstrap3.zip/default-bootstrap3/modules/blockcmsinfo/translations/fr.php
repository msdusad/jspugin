<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockcmsinfo}leo_hitechgame>blockcmsinfo_988659f6c5d3210a3f085ecfecccf5d3'] = 'Bloc CMS d\'information client';
$_MODULE['<{blockcmsinfo}leo_hitechgame>blockcmsinfo_cd4abd29bdc076fb8fabef674039cd6e'] = 'Ajoute un bloc d\'information client sur votre boutique.';
$_MODULE['<{blockcmsinfo}leo_hitechgame>blockcmsinfo_86432715902fbaf53de469fed3fa6c53'] = 'Vous devez sélectionner au moins une boutique.';
$_MODULE['<{blockcmsinfo}leo_hitechgame>blockcmsinfo_d52eaeff31af37a4a7e0550008aff5df'] = 'Une erreur est survenue lors de la sauvegarde';
$_MODULE['<{blockcmsinfo}leo_hitechgame>blockcmsinfo_6f16c729fadd8aa164c6c47853983dd2'] = 'Nouveau bloc CMS';
$_MODULE['<{blockcmsinfo}leo_hitechgame>blockcmsinfo_9dffbf69ffba8bc38bc4e01abf4b1675'] = 'Texte';
$_MODULE['<{blockcmsinfo}leo_hitechgame>blockcmsinfo_c9cc8cce247e49bae79f15173ce97354'] = 'Enregistrer';
$_MODULE['<{blockcmsinfo}leo_hitechgame>blockcmsinfo_630f6dc397fe74e52d5189e2c80f282b'] = 'Retour à la liste';
$_MODULE['<{blockcmsinfo}leo_hitechgame>blockcmsinfo_9d55fc80bbb875322aa67fd22fc98469'] = 'Boutiques associées';
$_MODULE['<{blockcmsinfo}leo_hitechgame>blockcmsinfo_6fcdef6ca2bb47a0cf61cd41ccf274f4'] = 'Identifiant du bloc';
$_MODULE['<{blockcmsinfo}leo_hitechgame>blockcmsinfo_9f82518d468b9fee614fcc92f76bb163'] = 'Boutique';
$_MODULE['<{blockcmsinfo}leo_hitechgame>blockcmsinfo_56425383198d22fc8bb296bcca26cecf'] = 'Texte du bloc';
$_MODULE['<{blockcmsinfo}leo_hitechgame>blockcmsinfo_ef61fb324d729c341ea8ab9901e23566'] = 'Ajouter';
