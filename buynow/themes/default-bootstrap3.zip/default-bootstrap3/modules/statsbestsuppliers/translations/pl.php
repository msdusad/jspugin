<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{statsbestsuppliers}leo_hitechgame>statsbestsuppliers_b5f5c19c8729b639d4d2a256fcb01a10'] = 'Zwrócono pusty zbiór danych';
$_MODULE['<{statsbestsuppliers}leo_hitechgame>statsbestsuppliers_f5c493141bb4b2508c5938fd9353291a'] = 'Wyświetlanie %1$s %2$s';
$_MODULE['<{statsbestsuppliers}leo_hitechgame>statsbestsuppliers_49ee3087348e8d44e1feda1917443987'] = 'Nazwa';
$_MODULE['<{statsbestsuppliers}leo_hitechgame>statsbestsuppliers_2a0440eec72540c5b30d9199c01f348c'] = 'Ilość sprzedana';
$_MODULE['<{statsbestsuppliers}leo_hitechgame>statsbestsuppliers_ea067eb37801c5aab1a1c685eb97d601'] = 'Zapłacono w sumie';
$_MODULE['<{statsbestsuppliers}leo_hitechgame>statsbestsuppliers_cc3eb9ba7d0e236f33023a4744d0693a'] = 'Najlepsi dostawcy';
$_MODULE['<{statsbestsuppliers}leo_hitechgame>statsbestsuppliers_37607fc64452028f4d484aa014071934'] = 'Dodaje listę najlepszych dostawców dla statystyki na tablicy.';
$_MODULE['<{statsbestsuppliers}leo_hitechgame>statsbestsuppliers_998e4c5c80f27dec552e99dfed34889a'] = 'Export CSV';
