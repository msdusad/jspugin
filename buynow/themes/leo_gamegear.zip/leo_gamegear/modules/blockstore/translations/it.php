<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockstore}leo_hitechgame>blockstore_68e9ecb0ab69b1121fe06177868b8ade'] = 'Blocco negozi';
$_MODULE['<{blockstore}leo_hitechgame>blockstore_c1104fe0bdaceb2e1c6f77b04977b64b'] = 'Consente di visualizzare un link d\'immagine alla funzione store locator di PrestaShop.';
$_MODULE['<{blockstore}leo_hitechgame>blockstore_b786bfc116ecf9a6d47ce1114ca6abb7'] = 'Questo modulo ha bisogno di essere ancorato ad una colonna e il tuo tema non ne implementa.';
$_MODULE['<{blockstore}leo_hitechgame>blockstore_7107f6f679c8d8b21ef6fce56fef4b93'] = 'L\'immagine non valido.';
$_MODULE['<{blockstore}leo_hitechgame>blockstore_df7859ac16e724c9b1fba0a364503d72'] = 'Si è verificato un errore durante il tentativo di caricare il file.';
$_MODULE['<{blockstore}leo_hitechgame>blockstore_efc226b17e0532afff43be870bff0de7'] = 'Le impostazioni sono state aggiornate.';
$_MODULE['<{blockstore}leo_hitechgame>blockstore_f4f70727dc34561dfde1a3c529b6205c'] = 'Impostazioni';
$_MODULE['<{blockstore}leo_hitechgame>blockstore_4d100d8b1b9bcb5a376f78365340cdbe'] = 'Immagine del blocco Store Locator';
$_MODULE['<{blockstore}leo_hitechgame>blockstore_a34202cc413553fe0fe2d46f706db435'] = 'Testo del blocco Store Locator';
$_MODULE['<{blockstore}leo_hitechgame>blockstore_c9cc8cce247e49bae79f15173ce97354'] = 'Salvare';
$_MODULE['<{blockstore}leo_hitechgame>blockstore_8c0caec5616160618b362bcd4427d97b'] = 'I nostri negozi!';
$_MODULE['<{blockstore}leo_hitechgame>blockstore_28fe12f949fd191685071517628df9b3'] = 'Scopri i nostri negozi!';
$_MODULE['<{blockstore}leo_hitechgame>blockstore_34c869c542dee932ef8cd96d2f91cae6'] = 'I nostri negozi';
$_MODULE['<{blockstore}leo_hitechgame>blockstore_61d5070a61ce6eb6ad2a212fdf967d92'] = 'Scopri i nostri negozi';
