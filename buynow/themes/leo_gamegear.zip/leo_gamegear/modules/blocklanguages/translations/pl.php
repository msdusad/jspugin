<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blocklanguages}leo_hitechgame>blocklanguages_d33f69bfa67e20063a8905c923d9cf59'] = 'Blok wyboru języka';
$_MODULE['<{blocklanguages}leo_hitechgame>blocklanguages_5bc2cbadb5e09b5ef9b9d1724072c4f9'] = 'Dodaje blok pozwalający klientom wybrać język dla zawartości twojego sklepu.';
$_MODULE['<{blocklanguages}leo_hitechgame>blocklanguages_7ba3eec2b4fa927d5294b456431a5eae'] = 'W językach: ';
