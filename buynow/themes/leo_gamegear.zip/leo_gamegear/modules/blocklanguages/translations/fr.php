<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blocklanguages}leo_hitechgame>blocklanguages_d33f69bfa67e20063a8905c923d9cf59'] = 'Bloc sélecteur de langue';
$_MODULE['<{blocklanguages}leo_hitechgame>blocklanguages_5bc2cbadb5e09b5ef9b9d1724072c4f9'] = 'Ajoute un bloc permettant aux clients de choisir une langue pour le contenu de votre magasin.';
$_MODULE['<{blocklanguages}leo_hitechgame>blocklanguages_7ba3eec2b4fa927d5294b456431a5eae'] = 'Langues: ';
