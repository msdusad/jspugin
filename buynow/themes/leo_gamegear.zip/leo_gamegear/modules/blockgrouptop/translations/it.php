<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockgrouptop}leo_hitechgame>blockgrouptop_9827d3df66ae8d506d0abc46ebc860b0'] = 'Block Group Top';
$_MODULE['<{blockgrouptop}leo_hitechgame>blockgrouptop_5bc2cbadb5e09b5ef9b9d1724072c4f9'] = 'Aggiunge un blocco che permette ai clienti di selezionare una lingua per i contenuti del tuo negozio.';
$_MODULE['<{blockgrouptop}leo_hitechgame>blockgrouptop_4994a8ffeba4ac3140beb89e8d41f174'] = 'Lingua';
$_MODULE['<{blockgrouptop}leo_hitechgame>blockgrouptop_386c339d37e737a436499d423a77df0c'] = 'Valuta';
