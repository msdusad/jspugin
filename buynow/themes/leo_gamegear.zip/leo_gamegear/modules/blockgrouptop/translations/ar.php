<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockgrouptop}leo_hitechgame>blockgrouptop_9827d3df66ae8d506d0abc46ebc860b0'] = 'كتلة المجموعة الأعلى';
$_MODULE['<{blockgrouptop}leo_hitechgame>blockgrouptop_5bc2cbadb5e09b5ef9b9d1724072c4f9'] = 'ويضيف لبنة مما يسمح للعملاء لاختيار لغة لتخزين المحتوى الخاص بك.';
$_MODULE['<{blockgrouptop}leo_hitechgame>blockgrouptop_4994a8ffeba4ac3140beb89e8d41f174'] = 'لغة';
$_MODULE['<{blockgrouptop}leo_hitechgame>blockgrouptop_386c339d37e737a436499d423a77df0c'] = 'عملة';
