<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blocknewproducts}leo_hitechgame>blocknewproducts_f7c34fc4a48bc683445c1e7bbc245508'] = 'Block Neue Artikel';
$_MODULE['<{blocknewproducts}leo_hitechgame>blocknewproducts_d3ee346c7f6560faa13622b6fef26f96'] = 'Zeigt einen Block mit neu hinzugefügten Artikeln an';
$_MODULE['<{blocknewproducts}leo_hitechgame>blocknewproducts_b15e7271053fe9dd22d80db100179085'] = 'Dieses Modul benötigen, um in einer Spalte eingehängt werden und Ihr Thema nicht ein implementieren';
$_MODULE['<{blocknewproducts}leo_hitechgame>blocknewproducts_1cd777247f2a6ed79534d4ace72d78ce'] = 'Sie müssen das Feld \"Angezeigte Artikel\" ausfüllen';
$_MODULE['<{blocknewproducts}leo_hitechgame>blocknewproducts_73293a024e644165e9bf48f270af63a0'] = 'Ungültige Anzahl.';
$_MODULE['<{blocknewproducts}leo_hitechgame>blocknewproducts_c888438d14855d7d96a2724ee9c306bd'] = 'Einstellungen aktualisiert';
$_MODULE['<{blocknewproducts}leo_hitechgame>blocknewproducts_f4f70727dc34561dfde1a3c529b6205c'] = 'Einstellungen';
$_MODULE['<{blocknewproducts}leo_hitechgame>blocknewproducts_26986c3388870d4148b1b5375368a83d'] = 'Anzuzeigende Artikel';
$_MODULE['<{blocknewproducts}leo_hitechgame>blocknewproducts_3ea7689283770958661c27c37275b89c'] = 'Anzahl der Artikel festlegen, die in diesem Block angezeigt werden sollen';
$_MODULE['<{blocknewproducts}leo_hitechgame>blocknewproducts_85dd6b2059e1ff8fbefcc9cf6e240933'] = 'Anzahl der Tage, in denen der Artikel als \"NEU\" angesehen wird';
$_MODULE['<{blocknewproducts}leo_hitechgame>blocknewproducts_24ff4e4d39bb7811f6bdf0c189462272'] = 'Immer diesen Block anzeigen';
$_MODULE['<{blocknewproducts}leo_hitechgame>blocknewproducts_d68e7b860a7dba819fa1c75225c284b5'] = 'Block anzeigen, auch wenn kein Artikel verfügbar ist';
$_MODULE['<{blocknewproducts}leo_hitechgame>blocknewproducts_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Aktiviert';
$_MODULE['<{blocknewproducts}leo_hitechgame>blocknewproducts_b9f5c797ebbf55adccdd8539a65a0241'] = 'Deaktiviert';
$_MODULE['<{blocknewproducts}leo_hitechgame>blocknewproducts_c9cc8cce247e49bae79f15173ce97354'] = 'Speichern';
$_MODULE['<{blocknewproducts}leo_hitechgame>blocknewproducts_9ff0635f5737513b1a6f559ac2bff745'] = 'Neue Produkte';
$_MODULE['<{blocknewproducts}leo_hitechgame>blocknewproducts_43340e6cc4e88197d57f8d6d5ea50a46'] = 'Mehr ...';
$_MODULE['<{blocknewproducts}leo_hitechgame>blocknewproducts_60efcc704ef1456678f77eb9ee20847b'] = 'Alle neuen Artikel';
$_MODULE['<{blocknewproducts}leo_hitechgame>blocknewproducts_18cc24fb12f89c839ab890f8188febe8'] = 'Aktuell Anzeige neuer Artikel nicht zulassen';
$_MODULE['<{blocknewproducts}leo_hitechgame>tab_a0d0ebc37673b9ea77dd7c1a02160e2d'] = 'Neu im Shop';
$_MODULE['<{blocknewproducts}leo_hitechgame>blocknewproducts_home_0af0aac2e9f6bd1d5283eed39fe265cc'] = 'Momentan keine neuen Artikel';
