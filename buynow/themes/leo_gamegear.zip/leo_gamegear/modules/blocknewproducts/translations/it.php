<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blocknewproducts}leo_hitechgame>blocknewproducts_f7c34fc4a48bc683445c1e7bbc245508'] = 'Blocco nuovi prodotti';
$_MODULE['<{blocknewproducts}leo_hitechgame>blocknewproducts_d3ee346c7f6560faa13622b6fef26f96'] = 'Visualizza un blocco con i prodotti appena aggiunti.';
$_MODULE['<{blocknewproducts}leo_hitechgame>blocknewproducts_b15e7271053fe9dd22d80db100179085'] = 'Questo modulo ha bisogno di essere agganciato in una colonna e il tema non implementa uno';
$_MODULE['<{blocknewproducts}leo_hitechgame>blocknewproducts_1cd777247f2a6ed79534d4ace72d78ce'] = 'Devi compilare il campo \"prodotti da visualizzare\".';
$_MODULE['<{blocknewproducts}leo_hitechgame>blocknewproducts_73293a024e644165e9bf48f270af63a0'] = 'Numero non valido.';
$_MODULE['<{blocknewproducts}leo_hitechgame>blocknewproducts_c888438d14855d7d96a2724ee9c306bd'] = 'Impostazioni aggiornati';
$_MODULE['<{blocknewproducts}leo_hitechgame>blocknewproducts_f4f70727dc34561dfde1a3c529b6205c'] = 'Impostazioni';
$_MODULE['<{blocknewproducts}leo_hitechgame>blocknewproducts_26986c3388870d4148b1b5375368a83d'] = 'Prodotti da visualizzare';
$_MODULE['<{blocknewproducts}leo_hitechgame>blocknewproducts_3ea7689283770958661c27c37275b89c'] = 'Imposta il numero di prodotti da visualizzare in questo blocco.';
$_MODULE['<{blocknewproducts}leo_hitechgame>blocknewproducts_85dd6b2059e1ff8fbefcc9cf6e240933'] = 'Numero di giorni in cui un prodotto possa essere considerato \"nuovo\"';
$_MODULE['<{blocknewproducts}leo_hitechgame>blocknewproducts_24ff4e4d39bb7811f6bdf0c189462272'] = 'Visualizzare sempre questo blocco';
$_MODULE['<{blocknewproducts}leo_hitechgame>blocknewproducts_d68e7b860a7dba819fa1c75225c284b5'] = 'Mostra il blocco anche se non nuovi prodotti sono disponibili.';
$_MODULE['<{blocknewproducts}leo_hitechgame>blocknewproducts_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Attivato';
$_MODULE['<{blocknewproducts}leo_hitechgame>blocknewproducts_b9f5c797ebbf55adccdd8539a65a0241'] = 'Disabile';
$_MODULE['<{blocknewproducts}leo_hitechgame>blocknewproducts_c9cc8cce247e49bae79f15173ce97354'] = 'Salvare';
$_MODULE['<{blocknewproducts}leo_hitechgame>blocknewproducts_9ff0635f5737513b1a6f559ac2bff745'] = 'Nuovi prodotti';
$_MODULE['<{blocknewproducts}leo_hitechgame>blocknewproducts_43340e6cc4e88197d57f8d6d5ea50a46'] = 'Maggiori informazioni';
$_MODULE['<{blocknewproducts}leo_hitechgame>blocknewproducts_60efcc704ef1456678f77eb9ee20847b'] = 'Tutti i nuovi prodotti';
$_MODULE['<{blocknewproducts}leo_hitechgame>blocknewproducts_18cc24fb12f89c839ab890f8188febe8'] = 'Non permettere nuovi prodotti al momento.';
$_MODULE['<{blocknewproducts}leo_hitechgame>tab_a0d0ebc37673b9ea77dd7c1a02160e2d'] = 'Nuovi arrivi';
$_MODULE['<{blocknewproducts}leo_hitechgame>blocknewproducts_home_0af0aac2e9f6bd1d5283eed39fe265cc'] = 'Nessun nuovo prodotto in questo momento.';
