<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockcmsinfo}leo_hitechgame>blockcmsinfo_988659f6c5d3210a3f085ecfecccf5d3'] = 'Własny blok informacyjny CMS';
$_MODULE['<{blockcmsinfo}leo_hitechgame>blockcmsinfo_cd4abd29bdc076fb8fabef674039cd6e'] = 'Dodaje bloki z własną informacją w Twoim sklepie.';
$_MODULE['<{blockcmsinfo}leo_hitechgame>blockcmsinfo_86432715902fbaf53de469fed3fa6c53'] = 'Musisz wybrać co najmniej jeden sklep.';
$_MODULE['<{blockcmsinfo}leo_hitechgame>blockcmsinfo_d52eaeff31af37a4a7e0550008aff5df'] = 'Wystąpił błąd podczas próby zapisu.';
$_MODULE['<{blockcmsinfo}leo_hitechgame>blockcmsinfo_6f16c729fadd8aa164c6c47853983dd2'] = 'Nowy własny blok CMS';
$_MODULE['<{blockcmsinfo}leo_hitechgame>blockcmsinfo_9dffbf69ffba8bc38bc4e01abf4b1675'] = 'Tekst';
$_MODULE['<{blockcmsinfo}leo_hitechgame>blockcmsinfo_c9cc8cce247e49bae79f15173ce97354'] = 'Oszczędzać';
$_MODULE['<{blockcmsinfo}leo_hitechgame>blockcmsinfo_630f6dc397fe74e52d5189e2c80f282b'] = 'Powrót do listy';
$_MODULE['<{blockcmsinfo}leo_hitechgame>blockcmsinfo_9d55fc80bbb875322aa67fd22fc98469'] = 'Powiązanie sklepu';
$_MODULE['<{blockcmsinfo}leo_hitechgame>blockcmsinfo_6fcdef6ca2bb47a0cf61cd41ccf274f4'] = 'Blok ID';
$_MODULE['<{blockcmsinfo}leo_hitechgame>blockcmsinfo_9f82518d468b9fee614fcc92f76bb163'] = 'Sklep';
$_MODULE['<{blockcmsinfo}leo_hitechgame>blockcmsinfo_56425383198d22fc8bb296bcca26cecf'] = 'Tekst bloku';
$_MODULE['<{blockcmsinfo}leo_hitechgame>blockcmsinfo_ef61fb324d729c341ea8ab9901e23566'] = 'Dodaj nowy';
