<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockcmsinfo}leo_hitechgame>blockcmsinfo_988659f6c5d3210a3f085ecfecccf5d3'] = 'Personalizar bloque de información CMS';
$_MODULE['<{blockcmsinfo}leo_hitechgame>blockcmsinfo_cd4abd29bdc076fb8fabef674039cd6e'] = 'Añade bloques de información personalizada en la tienda.';
$_MODULE['<{blockcmsinfo}leo_hitechgame>blockcmsinfo_86432715902fbaf53de469fed3fa6c53'] = 'Tiene que seleccionar al menos una tienda.';
$_MODULE['<{blockcmsinfo}leo_hitechgame>blockcmsinfo_d52eaeff31af37a4a7e0550008aff5df'] = 'Se produjo un error durante el proceso de almacenamiento';
$_MODULE['<{blockcmsinfo}leo_hitechgame>blockcmsinfo_6f16c729fadd8aa164c6c47853983dd2'] = 'Nueva personalización del bloque CMS';
$_MODULE['<{blockcmsinfo}leo_hitechgame>blockcmsinfo_9dffbf69ffba8bc38bc4e01abf4b1675'] = 'Textos';
$_MODULE['<{blockcmsinfo}leo_hitechgame>blockcmsinfo_c9cc8cce247e49bae79f15173ce97354'] = 'Guardar';
$_MODULE['<{blockcmsinfo}leo_hitechgame>blockcmsinfo_630f6dc397fe74e52d5189e2c80f282b'] = 'Volver a la lista';
$_MODULE['<{blockcmsinfo}leo_hitechgame>blockcmsinfo_9d55fc80bbb875322aa67fd22fc98469'] = 'Asociación de tienda';
$_MODULE['<{blockcmsinfo}leo_hitechgame>blockcmsinfo_6fcdef6ca2bb47a0cf61cd41ccf274f4'] = 'Bloque ID';
$_MODULE['<{blockcmsinfo}leo_hitechgame>blockcmsinfo_9f82518d468b9fee614fcc92f76bb163'] = 'Tienda';
$_MODULE['<{blockcmsinfo}leo_hitechgame>blockcmsinfo_56425383198d22fc8bb296bcca26cecf'] = 'Bloque de texto';
$_MODULE['<{blockcmsinfo}leo_hitechgame>blockcmsinfo_ef61fb324d729c341ea8ab9901e23566'] = 'Añadir nuevo';
