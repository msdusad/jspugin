<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockbanner}leo_hitechgame>blockbanner_4b92fcfe6f0ec26909935aa960b7b81f'] = 'Blocco Banner';
$_MODULE['<{blockbanner}leo_hitechgame>blockbanner_9ec3d0f07db2d25a37ec4b7a21c788f8'] = 'Mostra un banner nella parte alta del negozio.';
$_MODULE['<{blockbanner}leo_hitechgame>blockbanner_df7859ac16e724c9b1fba0a364503d72'] = 'Errore nel caricamento del file.';
$_MODULE['<{blockbanner}leo_hitechgame>blockbanner_efc226b17e0532afff43be870bff0de7'] = 'Le impostazioni sono state aggiornate.';
$_MODULE['<{blockbanner}leo_hitechgame>blockbanner_f4f70727dc34561dfde1a3c529b6205c'] = 'Impostazioni';
$_MODULE['<{blockbanner}leo_hitechgame>blockbanner_9edcdbdff24876b0dac92f97397ae497'] = 'Immagine del banner';
$_MODULE['<{blockbanner}leo_hitechgame>blockbanner_e90797453e35e4017b82e54e2b216290'] = 'Carica un\'immagine per il banner in alto. Le dimensioni raccomandate sono 1170 x 65 px se usi il tema predefinito.';
$_MODULE['<{blockbanner}leo_hitechgame>blockbanner_46fae48f998058600248a16100acfb7e'] = 'Link del banner';
$_MODULE['<{blockbanner}leo_hitechgame>blockbanner_084fa1da897dfe3717efa184616ff91c'] = 'Immetti il link associato al tuo banner. Cliccando sul banner, il link si apre nella stessa finestra. Se non viene immesso alcun link, esso reindirizza alla homepage.';
$_MODULE['<{blockbanner}leo_hitechgame>blockbanner_ff09729bee8a82c374f6b61e14a4af76'] = 'Descrizione banner';
$_MODULE['<{blockbanner}leo_hitechgame>blockbanner_112f6f9a1026d85f440e5ca68d8e2ec5'] = 'Si prega di inserire una breve ma significativa descrizione per il banner.';
$_MODULE['<{blockbanner}leo_hitechgame>blockbanner_c9cc8cce247e49bae79f15173ce97354'] = 'Salvare';
