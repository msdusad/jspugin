/* vim: set ts=2 sw=2 sts=2 et: */

/**
 * Language controller
 *
 * @author    Qualiteam software Ltd <info@x-cart.com>
 * @copyright Copyright (c) 2011-2015 Qualiteam software Ltd <info@x-cart.com>. All rights reserved
 * @license   http://www.x-cart.com/license-agreement.html X-Cart 5 License Agreement
 * @link      http://www.x-cart.com/
 */

/**
 * Controller
 */

function LanguageController(base)
{
  this.callSupermethod('constructor', arguments);
}

extend(LanguageController, AController);

// Controller name
LanguageController.prototype.name = 'LanguageController';

// Find pattern
LanguageController.prototype.findPattern = '.language-selector';

// Body handler is binded or not
LanguageController.prototype.bodyHandlerBinded = false;

// Initialize controller
LanguageController.prototype.initialize = function()
{
  if (!this.bodyHandlerBinded) {
    jQuery('body').click(_.bind(
        function (event) {
          this.toggleViewMode(false);
        },
        this
    ));

    this.bodyHandlerBinded = true;
  }

  jQuery(this.base).children('ul:first').click(_.bind(
      function(event, box) {
        event.stopPropagation();

        this.toggleViewMode()

        return false;
      },
      this
  ));

  jQuery('.items-list', this.base).click(
      function(event) {
        event.stopPropagation();
      }
  );
};

// Toggle view mode
LanguageController.prototype.toggleViewMode = function(expand)
{
  if (expand !== true && expand !== false) {
    expand = !this.base.hasClass('expanded');
  }

  if (expand) {
    this.base.addClass('expanded').removeClass('collapsed');
  } else {
    this.base.removeClass('expanded').addClass('collapsed');
  }
};

core.autoload(LanguageController);