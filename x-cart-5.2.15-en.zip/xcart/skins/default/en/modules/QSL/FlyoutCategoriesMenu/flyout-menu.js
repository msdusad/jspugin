/* vim: set ts=2 sw=2 sts=2 et: */

/**
 * Flyout-menu functions
 *
 * @author    Qualiteam software Ltd <info@x-cart.com>
 * @copyright Copyright (c) 2011-2015 Qualiteam software Ltd <info@x-cart.com>. All rights reserved
 * @license   http://www.x-cart.com/license-agreement.html X-Cart 5 License Agreement
 * @link      http://www.x-cart.com/
 */
jQuery(document).ready(function(){
    jQuery('ul.flyout-menu > li:not(.leaf) > a').on("touchstart", function (e) {
        
        jQuery('ul.flyout-menu').addClass('touch');        
        
        var link = jQuery(this);
        var li = jQuery(this).parent();
        if (link.hasClass('hover')) {
            li.addClass('hover');
            return true;
        } else {
            link.addClass('hover');
            jQuery('ul.flyout-menu > li > a').not(this).removeClass('hover');
            
            li.closest('ul.flyout-menu').find('li').removeClass('hover');
            li.addClass('hover');
            
            e.preventDefault();
            return false;
        }
    });    
});