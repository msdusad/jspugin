/* vim: set ts=2 sw=2 sts=2 et: */

/**
 * RSS feed controller
 *
 * @author    Qualiteam software Ltd <info@x-cart.com>
 * @copyright Copyright (c) 2011-2015 Qualiteam software Ltd <info@x-cart.com>. All rights reserved
 * @license   http://www.x-cart.com/license-agreement.html X-Cart 5 License Agreement
 * @link      http://www.x-cart.com/
 */
/*
function RSSFeedView(base)
{
  this.callSupermethod('constructor', arguments);

  jQuery(_.bind(this.load, this, {loadRSSData: true}));
}

extend(RSSFeedView, ALoadable);

RSSFeedView.prototype.widgetClass = '\\XLite\\View\\RSS';

RSSFeedView.autoload = function() {
  new RSSFeedView(jQuery('.rss-feed'));
};

core.autoload('RSSFeedView');
*/