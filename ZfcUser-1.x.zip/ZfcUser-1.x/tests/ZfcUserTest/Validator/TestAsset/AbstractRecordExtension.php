<?php

namespace ZfcUserTest\Validator\TestAsset;

use ZfcUser\Validator\AbstractRecord;

class AbstractRecordExtension extends AbstractRecord
{
    public function isValid($value)
    {

    }
}
