<?php
/**
 * Ids for poedit
 * @method translate()
 */
translate('Username');
translate('Email');
translate('New Email');
translate('Verify New Email');
translate('Display Name');
translate('Password');
translate('Password Verify');
translate('Current Password');
translate('Verify New Password');
translate('New Password');
translate('Please type the following text');
translate('Submit');
translate('Sign In');
translate('Register');
translate("No record matching the input was found");
translate("A record matching the input was found");
translate("Authentication failed. Please try again.");
