<?php

namespace ZfcUser\Exception;

class DomainException extends \RuntimeException implements
    ExceptionInterface
{
}
